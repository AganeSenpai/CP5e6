﻿using Microsoft.ML.Data;

namespace PrevisaoML.Models
{
    public class EntradaModel
    {
        [LoadColumn(0)]
        public float Idade { get; set; }

        [LoadColumn(1)]
        public float Experiencia { get; set; }

        [LoadColumn(2)]
        public float Salario { get; set; }  // Esta é a label
    }
}




