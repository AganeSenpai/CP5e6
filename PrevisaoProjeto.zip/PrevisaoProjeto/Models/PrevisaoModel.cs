﻿using Microsoft.ML.Data;

namespace PrevisaoML.Models
{
    public class PrevisaoModel
    {
        [ColumnName("Score")]
        public float Predicao { get; set; }
    }
}

