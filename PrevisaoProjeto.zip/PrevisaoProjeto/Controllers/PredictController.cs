using Microsoft.AspNetCore.Mvc;
using PrevisaoML.Models;
using PrevisaoML.Services;

namespace PrevisaoML.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PredictController : ControllerBase
    {
        private readonly MLService _mlService;

        public PredictController(MLService mlService)
        {
            _mlService = mlService;
        }

        [HttpPost("treinar")]
        public IActionResult Treinar()
        {
            var resultado = _mlService.TreinarModelo();
            return Ok(new { mensagem = resultado });
        }

        [HttpPost("prever")]
        public IActionResult Prever([FromBody] EntradaModel input)
        {
            var resultado = _mlService.Prever(input);
            return Ok(new { predicao = resultado });
        }
    }
}

