﻿using Microsoft.ML;
using PrevisaoML.Models;
using System;

namespace PrevisaoML.Services
{
    public class MLService
    {
        private readonly MLContext _mlContext;
        private ITransformer _modeloTreinado;
        private PredictionEngine<EntradaModel, PrevisaoModel> _predictionEngine;

        public MLService()
        {
            _mlContext = new MLContext();
        }

        public string TreinarModelo()
        {
            try
            {
                var caminhoArquivo = Path.Combine("Data", "dados.csv");

                var dataView = _mlContext.Data.LoadFromTextFile<EntradaModel>(
                    path: caminhoArquivo,
                    hasHeader: true,
                    separatorChar: ',');

                // 🔧 Adiciona a definição explícita de Label
                var pipeline = _mlContext.Transforms.CopyColumns("Label", nameof(EntradaModel.Salario))
                    .Append(_mlContext.Transforms.Concatenate("Features", nameof(EntradaModel.Idade), nameof(EntradaModel.Experiencia)))
                    .Append(_mlContext.Regression.Trainers.FastTree());

                _modeloTreinado = pipeline.Fit(dataView);

                _predictionEngine = _mlContext.Model.CreatePredictionEngine<EntradaModel, PrevisaoModel>(_modeloTreinado);

                return "Modelo treinado com sucesso!";
            }
            catch (Exception ex)
            {
                return $"Erro no treinamento: {ex.Message}";
            }
        }


        public float Prever(EntradaModel input)
        {
            if (_modeloTreinado == null)
            {
                Console.WriteLine("Modelo não treinado ainda.");
                return 0;
            }

            var predicao = _predictionEngine.Predict(input);
            Console.WriteLine($"Predição feita para Idade={input.Idade}, Experiencia={input.Experiencia} = {predicao.Predicao}");
            return predicao.Predicao;
        }
    }
}



